param(
  [string]$InputHtml = "index.html"
)
$ErrorActionPreference = "Stop"
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) { $python = Get-Command py -ErrorAction SilentlyContinue }
if (-not $python) {
  Write-Error "Python 3 is required. Use apply_v1.7.1_patch.py on any machine with Python 3."
}
& $python.Source "$PSScriptRoot\apply_v1.7.1_patch.py" $InputHtml

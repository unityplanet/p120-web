# P-120 v1.7.1 — Source-Reconciled Patch Bundle

This bundle is the exact-source reconciliation layer for the uploaded P-120 Web Editorial v1.7 `index.html`.

The ChatGPT File Library can read the source, but the current sandbox does not expose the attachment bytes at `/mnt/data/index.html`. For that reason this bundle deliberately does **not** fabricate a final Hosting Package from an older build.

## Included
- `MUSEUM_TEAL_PRODUCTION_OVERRIDE_v1.7.1.css`
- `apply_v1.7.1_patch.py`
- `APPLY_PATCH_WINDOWS.ps1`
- `VISUAL_REGRESSION_AUDIT_v1.7.1_SOURCE_RECONCILED.md`
- `CHANGELOG_v1.7.1.md`
- `QA_REPORT_v1.7.1_SOURCE_RECONCILED.md`
- `PATCH_MANIFEST_v1.7.1.json`
- Museum Teal styleboard previews

## Deterministic patch behaviour
The patcher:
1. validates signatures unique to the uploaded v1.7 build;
2. appends the final Museum Teal cascade before the existing `</style>`;
3. changes only Museum `theme-color`;
4. changes only the Russian Museum label;
5. keeps the `museum` state/localStorage key;
6. writes `index_v1.7.1.html`.

It refuses to run if the expected v1.7 signatures are missing or the file is already patched.

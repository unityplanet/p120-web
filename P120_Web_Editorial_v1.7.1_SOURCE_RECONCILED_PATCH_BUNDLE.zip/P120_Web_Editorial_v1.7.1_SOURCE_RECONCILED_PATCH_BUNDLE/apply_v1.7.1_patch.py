#!/usr/bin/env python3
"""
P-120 Web Editorial v1.7 -> v1.7.1 Museum Teal
Deterministic source-preserving patcher.

Only:
1) appends the verified Museum Teal production override before </style>;
2) changes Museum runtime theme-color;
3) changes the Russian UI label from "Тёмный музей" to "Музейная".

All other source bytes are preserved.
"""
from pathlib import Path
import hashlib, sys

MARKER = "P-120 Web Editorial v1.7.1 — Museum Teal Restoration"
CSS_FILE = "MUSEUM_TEAL_PRODUCTION_OVERRIDE_v1.7.1.css"

def sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def fail(msg):
    raise SystemExit("ERROR: " + msg)

def main():
    src = Path(sys.argv[1] if len(sys.argv) > 1 else "index.html")
    if not src.exists():
        fail(f"input not found: {src}")
    raw = src.read_bytes()
    text = raw.decode("utf-8")

    required = [
        "P-120 Web Editorial v1.7",
        "Render-Led Visual System",
        "render-opening",
        "render-thesis-panel",
        "body[data-theme='museum']",
        "museum:'#171411'",
        "museum:'Тёмный музей'",
        "</style>",
    ]
    missing = [s for s in required if s not in text]
    if missing:
        fail("v1.7 signatures missing: " + ", ".join(repr(x) for x in missing))

    if MARKER in text:
        fail("file already appears patched to v1.7.1")

    css_path = Path(__file__).with_name(CSS_FILE)
    if not css_path.exists():
        fail(f"override missing: {css_path}")
    css = css_path.read_text(encoding="utf-8").strip()

    # Preserve all original code; append one final cascade layer.
    injected = "\n\n/* " + MARKER + " */\n" + css + "\n"
    text = text.replace("</style>", injected + "</style>", 1)

    # Runtime UI-only edits; state key remains `museum`.
    text = text.replace("museum:'#171411'", "museum:'#F2EEE2'", 1)
    text = text.replace("museum:'Тёмный музей'", "museum:'Музейная'", 1)

    out = src.with_name("index_v1.7.1.html")
    out.write_text(text, encoding="utf-8", newline="")

    print("INPUT_SHA256 ", sha256(raw))
    print("OUTPUT_SHA256", sha256(out.read_bytes()))
    print("OUTPUT       ", out)
    print("LOCK         measurement/scoring/items/claims/archetypes/compatibility/result logic: untouched")
    print("THEME_KEY    museum (preserved)")
    print("THEME_LABEL  Музейная / Museum Teal")

if __name__ == "__main__":
    main()

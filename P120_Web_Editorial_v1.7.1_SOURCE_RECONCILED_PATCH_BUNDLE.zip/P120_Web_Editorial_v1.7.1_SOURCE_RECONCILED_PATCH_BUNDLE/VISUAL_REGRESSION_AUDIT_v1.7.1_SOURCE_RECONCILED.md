# P-120 Web Editorial v1.7.1 — Visual Regression Audit / Source-Reconciled Addendum

**Target:** Museum Teal Restoration & Visual Regression Correction  
**Base inspected:** uploaded exact v1.7 `index.html` through File Library source extraction  
**Status:** SOURCE RECONCILIATION COMPLETE / BINARY MUTATION RUNTIME-BLOCKED

## Confirmed in the actual v1.7 source

- Theme registry is exactly `ivory / graphite / museum`; the `museum` key can be retained without state migration.
- Runtime label is `Тёмный музей`.
- Runtime Museum `theme-color` is `#171411`.
- Museum token map is a true dark system: canvas `#171411`, elevated `#1d1a17`, surface `#211e1a`, surface-soft `#26221e`, surface-deep `#12100e`.
- v1.7 semantic component parity already covers:
  - hero / support inserts / thesis / Manifestations / dimensions / Two Systems / distinctions / orbital map;
  - science;
  - questionnaire / preflight / transition / results;
  - progress;
  - report preview;
  - mobile drawer and bottom navigation.
- Render-Led geometry fixes are already present (`render-opening`, `semantic-two-systems`, dimension/orbit architecture). They are not reopened in v1.7.1.

## Regression classification

| Area | Decision |
|---|---|
| v1.7 Render-Led composition | KEEP FROM v1.7 |
| hero / thesis / Manifestations / Nine Dimensions / Two Systems / A≠B / central architecture | KEEP FROM v1.7 |
| responsive / HD / QHD / UHD / mobile geometry | NO CHANGE |
| third-theme luminance/material identity | RESTORE FROM v1.6.1 + REBUILD |
| dark Museum canvas | REMOVE |
| cream / stone / sand / grey-green daylight material | RESTORE |
| structural teal / turquoise | RESTORE |
| orbital geometry | KEEP, recolour/material rebuild only |
| science integration | KEEP, skin rebuild only |
| questionnaire UX | KEEP, selection/progress skin rebuild only |
| Dark Museum as mandatory Theme 3 | REMOVE |
| Dark Museum as optional Theme 4 | NOT ADDED in v1.7.1 |

## Non-colour audit decision

No geometry change is authorised in this pass unless confirmed by a runnable exact-binary visual test. The source already contains explicit release-blocker geometry corrections; changing them without the binary render would turn v1.7.1 into an uncontrolled redesign.

Therefore this correction is intentionally narrow:
- material hierarchy;
- theme polarity;
- component skin;
- contrast/focus;
- theme label/meta colour.

## Frozen lock

Measurement logic changed: **NO**  
Scoring logic changed: **NO**  
Question wording changed: **NO**  
Scientific claims changed: **NO**  
Archetypes changed: **NO**  
Compatibility logic changed: **NO**  
Result calculation changed: **NO**  
Frozen source blocks changed: **NO**
